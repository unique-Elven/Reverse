////////////////////////////////////////////////////////////////////////////////
//
//  FileName    :   ustrref.h
//  Version     :   1.0
//  Creater     :   Luo Cong
//  Date        :   2006-7-31 11:55:03
//  Comment     :   
//
////////////////////////////////////////////////////////////////////////////////

#ifndef __USTRREF_H__
#define __USTRREF_H__

extern DWORD g_dwCurEip;

#define defINITCPUSEL           "(Initial CPU selection)"
#define defINIKEY               "Restore UStrRef Window"
#define defPLUGINNAME           "Ultra String Reference Plugin"
#define defPASSEDTHEENDOFFILE   "Passed the end of file"

#endif  // __USTRREF_H__