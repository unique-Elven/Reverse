# Maye NetWork

Maye NetWork 是一系列C/C++编写的基于Windows的网络代码库，用于创建可在C/C++中调用的工具库。



### 入门

所有程序都基于VS系列软件开发，仓库自带Vs的项目文件，克隆之后点击.sln文件，把需要的项目设置为启动项，运行代码即可~

克隆整个仓库，请运行以下命令：

```css
git clone https://github.com/zcmaye/NetWork.git
cd NetWork
点击.sln    
```



### 项目

+ **CSmtp**  C语言邮件发送系统
+ **CFtp** C语言编写的文件传输系统
+ **CHttp** C语语言http服务器
